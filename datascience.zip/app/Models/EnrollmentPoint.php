<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EnrollmentPoint extends Model
{
    protected $fillable = ['point'];
}
