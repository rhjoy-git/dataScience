<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FooterData extends Model
{
    protected $fillable = ['courses', 'resources', 'legal', 'contact'];
}
