<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CoursePart extends Model
{
    protected $casts = ['algorithms' => 'array'];
}
